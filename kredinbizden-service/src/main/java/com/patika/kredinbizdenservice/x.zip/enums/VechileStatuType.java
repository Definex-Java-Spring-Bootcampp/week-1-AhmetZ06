package com.patika.kredinbizdenservice.enums;

public enum VechileStatuType {

    NEW,
    USED

}
