package com.patika.kredinbizdenservice.model;

public interface Product {

}
