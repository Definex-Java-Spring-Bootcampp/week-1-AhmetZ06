package com.patika.kredinbizdenservice.enums;
public enum LoanType {

    IHTIYAC_KREDISI,
    KONUT_KREDISI,
    ARAC_KREDISI
}
