package com.patika.kredinbizdenservice.enums;

public enum SectorType {

    MARKET,
    TRAVELS,
    OTHERS,


}
