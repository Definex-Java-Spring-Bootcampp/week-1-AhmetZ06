package com.patika.kredinbizdenservice.enums;

public enum ApplicationStatus {

    INITIAL,
    IN_PROGRESS,
    DONE
}
